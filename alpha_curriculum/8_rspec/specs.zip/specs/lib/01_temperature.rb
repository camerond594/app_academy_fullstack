def ftoc(fahrenheit)
  return (fahrenheit - 32) * (5.0 / 9.0)
end

def ctof(celcius)
  return celcius * (9.0/5.0) + 32
end
